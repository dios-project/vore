import requests

index_url_text = "https://raw.githubusercontent.com/dios-project/vore/master/"
index_url = requests.get(index_url_text)
index_url.encoding = "utf8"
index_text = index_url.text


game=input("oyun>")
game_url = index_url_text + game
game_url = requests.get(game_url)
if game_url.text == "404: Not Found":
    print("Not Found")
else:
    with open(f"temp/{game.zip}"
